
enum DashboardTab {
  home,
  clients,
  equipment,
  rents,
  payments,
  reports,
  users,
}
