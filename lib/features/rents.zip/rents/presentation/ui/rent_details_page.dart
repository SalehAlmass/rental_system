import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/network/api_client.dart';
import '../../../../core/network/failure.dart';
import '../../../payments/data/repositories/payments_repository_impl.dart';
import '../../../payments/domain/entities/models.dart';
import '../../../payments/presentation/ui/payment_details_page.dart';
import '../../../settings/data/contract_closing_settings_repository.dart';
import '../../data/repositories/rents_repository_impl.dart';
import '../../domain/entities/models.dart';

class RentDetailsPage extends StatefulWidget {
  const RentDetailsPage({super.key, required this.rentId});
  final int rentId;

  @override
  State<RentDetailsPage> createState() => _RentDetailsPageState();
}

class _RentDetailsPageState extends State<RentDetailsPage> {
  late final ApiClient _api;
  late final PaymentsRepository _paymentsRepo;
  late final RentsRepository _rentsRepo;
  late final ContractClosingSettingsRepository _closingSettingsRepo;

  bool _loading = true;
  bool _closing = false;
  bool _savingFollowup = false;

  Rent? _rent;
  List<Payment> _rentPayments = const [];
  List<Rent> _clientOutstandingRents = const [];
  List<CollectionFollowup> _followups = const [];
  List<CollectionFollowup> _clientFollowups = const [];
  double _total = 0;
  double _paid = 0;
  double _remaining = 0;
  bool _fullyPaid = false;

  final Map<String, String> _sectionErrors = {};

  @override
  void initState() {
    super.initState();
    _api = context.read<ApiClient>();
    _paymentsRepo = PaymentsRepository(_api);
    _rentsRepo = RentsRepository(_api);
    _closingSettingsRepo = ContractClosingSettingsRepository(_api);
    _load();
  }

  Future<void> _load() async {
  setState(() => _loading = true);
  try {
    await Future.wait([
      _fetchFinancials().catchError((_){}),
      _fetchRentPayments().catchError((_){}),
      _fetchClientOutstandingRents().catchError((_){}),
      _fetchCollectionFollowups().catchError((_){}),
      _fetchClientFollowups().catchError((_){}),
    ]);
  } finally {
    if (mounted) setState(() => _loading = false);
  }
}



  Future<void> _runSection(String key, Future<void> Function() task, {bool fatal = false}) async {
    try {
      await task();
      if (!mounted) return;
      setState(() => _sectionErrors.remove(key));
    } catch (e) {
      if (!mounted) return;
      final msg = _friendlyError(e);
      setState(() => _sectionErrors[key] = msg);
      if (fatal) {
        _snack(msg);
      }
    }
  }

  String _friendlyError(Object error) {
    final text = error.toString();
    if (text.contains('Unexpected token') || text.contains('FormatException') || text.contains('is not valid JSON')) {
      return 'السيرفر أعاد استجابة غير صالحة بدل JSON. راجع ملف API أو سجل أخطاء PHP.';
    }
    if (text.contains('404')) return 'المسار المطلوب غير موجود في API.';
    return text.replaceFirst('Exception: ', '');
  }

  dynamic _unwrapResponseData(dynamic raw) {
    if (raw is String) {
      final s = raw.trimLeft();
      if (s.startsWith('<')) {
        throw ApiFailure('API returned HTML instead of JSON: $s');
      }
      throw ApiFailure('API returned plain text instead of JSON: $s');
    }
    if (raw is Map) {
      return raw['data'] ?? raw['items'] ?? raw['rent'] ?? raw['followups'] ?? raw;
    }
    return raw;
  }

  double _numToDouble(dynamic v) {
    if (v is num) return v.toDouble();
    return double.tryParse(v?.toString() ?? '') ?? 0.0;
  }

  Future<void> _fetchFinancials() async {
    try {
      final res = await _api.dio.get('rents/${widget.rentId}/financials');
      final raw = _unwrapResponseData(res.data);
      if (raw is! Map) throw ApiFailure('financials payload is invalid');

      final rentJson = (raw['rent'] is Map) ? (raw['rent'] as Map).cast<String, dynamic>() : null;
      if (rentJson == null) throw ApiFailure('financials: rent is missing');

      final rent = Rent.fromJson(rentJson);
      final total = _numToDouble(raw['total_amount']);
      final paid = _numToDouble(raw['paid_amount']);
      final remaining = _numToDouble(raw['remaining_amount'] ?? raw['remaining']);
      final isPaidServer = (raw['is_paid'] == true) || (raw['is_fully_paid'] == true);

      final status = (rent.status ?? '').toLowerCase();
      final fullyPaidSafe = status == 'open' ? false : isPaidServer;

      if (!mounted) return;
      setState(() {
        _rent = rent;
        _total = total;
        _paid = paid;
        _remaining = remaining < 0 ? 0 : remaining;
        _fullyPaid = fullyPaidSafe;
      });
    } catch (_) {
      final rent = await _rentsRepo.get(widget.rentId);
      if (!mounted) return;
      setState(() {
        _rent = rent;
        _total = rent.totalAmount ?? 0;
        _paid = rent.paidAmount ?? rent.closingPaidAmount ?? 0;
        _remaining = _remainingFor(rent);
        _fullyPaid = (rent.status ?? '').toLowerCase() == 'open' ? false : (rent.isPaid ?? false);
      });
    }
  }

  Future<void> _fetchRentPayments() async {
    try {
      final items = await _paymentsRepo.list(rentId: widget.rentId, showVoided: true);
      if (!mounted) return;
      setState(() => _rentPayments = items);
    } catch (e) {
      if (!mounted) return;
      setState(() => _rentPayments = const []);
      rethrow;
    }
  }

  Future<void> _fetchClientOutstandingRents() async {
    final rent = _rent;
    if (rent == null) return;

    try {
      final items = await _rentsRepo.list(clientId: rent.clientId);
      final outstanding = items.where((item) {
        if (item.id == rent.id) return false;
        final remaining = _remainingFor(item);
        return remaining > 0.009 && (item.status ?? '').toLowerCase() != 'cancelled';
      }).toList();

      if (!mounted) return;
      setState(() => _clientOutstandingRents = outstanding);
    } catch (e) {
      if (!mounted) return;
      setState(() => _clientOutstandingRents = const []);
      rethrow;
    }
  }

  Future<void> _fetchCollectionFollowups() async {
    try {
      final res = await _api.dio.get('rents/${widget.rentId}/collection-followups');
      dynamic raw = _unwrapResponseData(res.data);
      if (raw is! List) raw = [];
      final items = raw
          .whereType<Map>()
          .map((e) => CollectionFollowup.fromJson(e.cast<String, dynamic>()))
          .toList();
      if (!mounted) return;
      setState(() => _followups = items);
    } catch (e) {
      if (!mounted) return;
      setState(() => _followups = const []);
      rethrow;
    }
  }

  Future<void> _fetchClientFollowups() async {
    final rent = _rent;
    if (rent == null) return;
    try {
      final res = await _api.dio.get('clients/${rent.clientId}/collection-followups');
      dynamic raw = _unwrapResponseData(res.data);
      if (raw is! List) raw = [];
      final items = raw
          .whereType<Map>()
          .map((e) => CollectionFollowup.fromJson(e.cast<String, dynamic>()))
          .toList();
      if (!mounted) return;
      setState(() => _clientFollowups = items);
    } catch (e) {
      if (!mounted) return;
      setState(() => _clientFollowups = const []);
      rethrow;
    }
  }

  Future<void> _createCollectionFollowup(_CollectionFollowupDraft draft, {bool allowDuplicateToday = false}) async {
    final rent = _rent;
    if (rent == null || _savingFollowup) return;
    setState(() => _savingFollowup = true);
    try {
      await _api.dio.post(
        'rents/${rent.id}/collection-followups',
        data: {
          'contact_type': draft.contactType,
          'outcome': draft.outcome,
          'note': draft.note,
          'next_followup_at': draft.nextFollowupAt?.toIso8601String(),
          'allow_duplicate_today': allowDuplicateToday,
        },
      );
      await _fetchCollectionFollowups();
      await _fetchClientFollowups();
      if (!mounted) return;
      _snack('تم حفظ متابعة التحصيل');
    } on DioException catch (e) {
      if (!mounted) return;
      final data = e.response?.data;
      final msg = data is Map && data['error'] != null ? data['error'].toString() : e.message ?? e.toString();
      _snack('فشل حفظ متابعة التحصيل: $msg');
    } catch (e) {
      if (!mounted) return;
      _snack('فشل حفظ متابعة التحصيل: ${_friendlyError(e)}');
    } finally {
      if (mounted) setState(() => _savingFollowup = false);
    }
  }

  String _followupActor(CollectionFollowup item) {
    final name = item.createdByName?.trim();
    if (name != null && name.isNotEmpty) return name;
    return 'الموظف #${item.createdByUserId ?? '-'}';
  }

  Future<void> _openCollectionFollowupDialog() async {
    final todays = _todayClientFollowup;
    if (todays != null) {
      final proceed = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('تم التواصل اليوم مع هذا العميل'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('آخر متابعة اليوم كانت ${_fmtDateTime(todays.createdAt)}'),
              const SizedBox(height: 8),
              Text('النوع: ${todays.contactTypeLabel}'),
              Text('النتيجة: ${todays.outcomeLabel}'),
              Text('الموظف: ${_followupActor(todays)}'),
              if ((todays.note ?? '').trim().isNotEmpty) ...[
                const SizedBox(height: 8),
                Text('ملاحظة: ${todays.note!.trim()}'),
              ],
              const SizedBox(height: 12),
              const Text('حتى لا يتكرر التواصل مع نفس العميل في نفس اليوم، راجع المتابعة السابقة أولاً.'),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
            OutlinedButton(
              onPressed: () {
                Navigator.pop(context, false);
                _showFollowupsSheet(context);
              },
              child: const Text('عرض السجل'),
            ),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('إضافة متابعة إضافية')),
          ],
        ),
      );
      if (proceed != true) return;
    }

    final draft = await showDialog<_CollectionFollowupDraft>(
      context: context,
      builder: (_) => _CollectionFollowupDialog(
        initialHint: todays == null ? null : 'تم التواصل اليوم بواسطة ${_followupActor(todays)} • ${todays.contactTypeLabel} • ${todays.outcomeLabel}',
      ),
    );
    if (draft == null) return;
    await _createCollectionFollowup(draft, allowDuplicateToday: todays != null);
  }

  Future<void> _closeContract() async {
    final rent = _rent;
    if (rent == null || _closing) return;

    try {
      final settings = await _closingSettingsRepo.fetch();
      if (!mounted) return;

      final result = await showDialog<_CloseContractResult>(
        context: context,
        builder: (_) => _CloseContractDialog(
          rent: rent,
          settings: settings,
          currentPaid: _paid,
        ),
      );

      if (result == null) return;

      setState(() => _closing = true);

      await _rentsRepo.closeRent(
        rentId: rent.id,
        endDatetime: DateTime.now().toIso8601String(),
        applySpecialPricing: result.applySpecialPricing,
        paidAmount: result.paidAmount,
        paymentMethod: result.paymentMethod,
        createReceipt: result.createReceipt,
        paymentNotes: result.paymentNotes,
        idempotencyKey: 'rent_close_${rent.id}_${DateTime.now().millisecondsSinceEpoch}',
      );

      await _load();
      if (!mounted) return;
      _snack('تم إغلاق العقد بنجاح');
    } catch (e) {
      if (!mounted) return;
      _snack('فشل إغلاق العقد: ${_friendlyError(e)}');
    } finally {
      if (mounted) setState(() => _closing = false);
    }
  }

  Future<void> _showPayDialog({required Rent rent}) async {
    if (!mounted) return;

    await _runSection('financials', _fetchFinancials);

    final status = (rent.status ?? '').toLowerCase();
    final isOpen = status == 'open';

    if (!isOpen && _remaining <= 0.0001) {
      _snack('هذا العقد مسدد بالكامل ولا يمكن إنشاء سند جديد');
      return;
    }

    final maxPayable = _remaining;

    await showDialog(
      context: context,
      builder: (_) => _PayNowDialog(
        total: _total,
        alreadyPaid: _paid,
        maxPayable: maxPayable <= 0 ? 0 : maxPayable,
        unlimitedWhenOpen: isOpen && (_total <= 0.0001),
        onPay: (amount, method, notes) async {
          final idemKey = 'rent_${rent.id}_${DateTime.now().microsecondsSinceEpoch}';
          await _paymentsRepo.create(
            type: 'in',
            amount: amount,
            clientId: rent.clientId,
            rentId: rent.id,
            method: method,
            notes: notes,
            idempotencyKey: idemKey,
          );
        },
      ),
    );

    await _runSection('financials', _fetchFinancials);
    await _runSection('payments', _fetchRentPayments);
  }

  double _remainingFor(Rent rent) {
    final direct = rent.remainingAmount;
    if (direct != null) return direct < 0 ? 0 : direct;
    final total = rent.totalAmount ?? 0;
    final paid = rent.paidAmount ?? rent.closingPaidAmount ?? 0;
    final remaining = total - paid;
    return remaining > 0 ? remaining : 0;
  }

  Payment? get _lastPayment {
    final valid = _rentPayments.where((p) => !p.isVoid).toList();
    if (valid.isEmpty) return null;
    valid.sort((a, b) {
      final ad = DateTime.tryParse((a.createdAt ?? '').replaceFirst(' ', 'T')) ?? DateTime.fromMillisecondsSinceEpoch(0);
      final bd = DateTime.tryParse((b.createdAt ?? '').replaceFirst(' ', 'T')) ?? DateTime.fromMillisecondsSinceEpoch(0);
      return bd.compareTo(ad);
    });
    return valid.first;
  }

  CollectionFollowup? get _latestFollowup => _followups.isEmpty ? null : _followups.first;
  CollectionFollowup? get _latestClientFollowup => _clientFollowups.isEmpty ? null : _clientFollowups.first;
  CollectionFollowup? get _todayClientFollowup {
    for (final item in _clientFollowups) {
      final dt = _tryParse(item.createdAt);
      if (dt == null) continue;
      final now = DateTime.now();
      if (dt.year == now.year && dt.month == now.month && dt.day == now.day) {
        return item;
      }
    }
    return null;
  }

  DateTime? _tryParse(String? value) {
    if (value == null || value.isEmpty) return null;
    return DateTime.tryParse(value.replaceFirst(' ', 'T'));
  }

  bool get _hasDeferredPayment => _remaining > 0.009;

  bool get _isCollectionDelayed {
    if (!_hasDeferredPayment) return false;
    final status = (_rent?.status ?? '').toLowerCase();
    if (status != 'closed') return false;
    final closedAt = DateTime.tryParse((_rent?.closedAt ?? '').replaceFirst(' ', 'T'));
    if (closedAt == null) return false;
    return DateTime.now().difference(closedAt).inDays >= 3;
  }

  @override
  Widget build(BuildContext context) {
    final rent = _rent;
    final status = ((rent?.status ?? '')).toLowerCase();
    final isOpen = status == 'open';

    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل العقد'), centerTitle: true),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : (rent == null)
              ? Center(child: Text(_sectionErrors['financials'] ?? 'تعذر تحميل العقد'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      if (_sectionErrors.isNotEmpty) ...[
                        _buildErrorsBanner(),
                        const SizedBox(height: 12),
                      ],
                      _card(
                        title: 'معلومات العقد',
                        child: Column(
                          children: [
                            _kv('رقم العقد', '#${rent.id}'),
                            _kv('العميل', rent.clientName ?? rent.clientId.toString()),
                            _kv('المعدة', rent.equipmentName ?? rent.equipmentId.toString()),
                            _kv('الحالة', _statusText(rent.status)),
                            _kv('بداية', _fmtDateTime(rent.startDatetime)),
                            _kv('نهاية', rent.endDatetime == null ? '-' : _fmtDateTime(rent.endDatetime!)),
                            const Divider(height: 18),
                            _kv('الإجمالي', isOpen && _total <= 0.0001 ? 'غير نهائي (العقد جاري)' : '${_total.toStringAsFixed(2)} ر.س'),
                            _kv('المدفوع', '${_paid.toStringAsFixed(2)} ر.س'),
                            _kv('المتبقي', isOpen && _total <= 0.0001 ? '-' : '${_remaining.toStringAsFixed(2)} ر.س'),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      _card(
                        title: 'معلومات الإغلاق',
                        child: Column(
                          children: [
                            _kv('وقت الإغلاق', rent.closedAt == null ? '-' : _fmtDateTime(rent.closedAt!)),
                            _kv('رقم المستخدم', rent.closedByUserId?.toString() ?? '-'),
                            _kv('المبلغ عند الإغلاق', '${(rent.closingPaidAmount ?? 0).toStringAsFixed(2)} ر.س'),
                            _kv('طريقة الدفع', _paymentMethodText(rent.closingPaymentMethod)),
                            _kv('حالة السند', _receiptStatusText(rent.closingPaymentStatus)),
                            _kv('رقم السند', rent.closingPaymentId?.toString() ?? '-'),
                            _kv('طريقة الاحتساب', rent.pricingRuleLabel ?? 'الاحتساب القياسي'),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      _card(
                        title: 'حالة التحصيل',
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (_hasDeferredPayment) _buildCollectionBanner(context),
                            _buildFinancialStrip(isOpen: isOpen),
                            const SizedBox(height: 12),
                            _buildLastPaymentCard(context),
                            const SizedBox(height: 12),
                            _buildFollowupCard(context),
                            if (_clientOutstandingRents.isNotEmpty) ...[
                              const SizedBox(height: 12),
                              _buildOtherOutstandingBanner(),
                            ],
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                FilledButton.icon(
                                  onPressed: () => _showPayDialog(rent: rent),
                                  icon: const Icon(Icons.add_card_outlined),
                                  label: const Text('إضافة دفعة'),
                                ),
                                OutlinedButton.icon(
                                  onPressed: _rentPayments.isEmpty ? null : () => _showPaymentsSheet(context),
                                  icon: const Icon(Icons.receipt_long_outlined),
                                  label: Text(_rentPayments.isEmpty ? 'لا توجد سندات' : 'عرض السندات (${_rentPayments.length})'),
                                ),
                                if (isOpen)
                                  FilledButton.tonalIcon(
                                    onPressed: _closing ? null : _closeContract,
                                    icon: Icon(_closing ? Icons.hourglass_top : Icons.lock_outline),
                                    label: Text(_closing ? 'جاري الإغلاق...' : 'إغلاق العقد'),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget _buildErrorsBanner() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.orange.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.orange.withOpacity(0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('بعض الأقسام لم تُحمّل بالكامل', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          ..._sectionErrors.entries.map((e) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text('• ${_sectionLabel(e.key)}: ${e.value}'),
              )),
        ],
      ),
    );
  }

  String _sectionLabel(String key) {
    switch (key) {
      case 'financials':
        return 'البيانات المالية';
      case 'payments':
        return 'السندات';
      case 'outstanding':
        return 'العقود الأخرى';
      case 'followups':
        return 'متابعات العقد';
      case 'client_followups':
        return 'متابعات العميل';
      default:
        return key;
    }
  }

  // ===== Existing UI helpers kept simple =====
  Widget _buildCollectionBanner(BuildContext context) => Container();
  Widget _buildFinancialStrip({required bool isOpen}) => Container();
  Widget _buildLastPaymentCard(BuildContext context) => Container();
  Widget _buildFollowupCard(BuildContext context) => Container();
  Widget _buildOtherOutstandingBanner() => Container();
  void _showPaymentsSheet(BuildContext context) {}
  void _showFollowupsSheet(BuildContext context) {}
  Widget _card({required String title, required Widget child}) => Card(child: Padding(padding: const EdgeInsets.all(12), child: child));
  Widget _kv(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [Expanded(child: Text(k)), Text(v)]),
      );
  Widget _miniMetric(String title, String value) => Column(children: [Text(title), const SizedBox(height: 4), Text(value)]);
  String _statusText(String? s) => s ?? '-';
  String _paymentMethodText(String? s) => s ?? '-';
  String _receiptStatusText(String? s) => s ?? '-';
  String _fmtDateTime(String? s) => s ?? '-';
  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }
}

class _CollectionFollowupDraft {
  _CollectionFollowupDraft({required this.contactType, required this.outcome, required this.note, this.nextFollowupAt});
  final String contactType;
  final String outcome;
  final String note;
  final DateTime? nextFollowupAt;
}

class _CollectionFollowupDialog extends StatelessWidget {
  const _CollectionFollowupDialog({this.initialHint});
  final String? initialHint;
  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('إضافة متابعة'),
        content: Text(initialHint ?? 'غير متاح في هذا الإصلاح المختصر'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق'))],
      );
}

class _CloseContractResult {
  _CloseContractResult({required this.applySpecialPricing, required this.paidAmount, required this.paymentMethod, required this.createReceipt, this.paymentNotes});
  final bool applySpecialPricing;
  final double paidAmount;
  final String paymentMethod;
  final bool createReceipt;
  final String? paymentNotes;
}

class _CloseContractDialog extends StatelessWidget {
  const _CloseContractDialog({required this.rent, required this.settings, required this.currentPaid});
  final Rent rent;
  final dynamic settings;
  final double currentPaid;
  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('إغلاق العقد'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء'))],
      );
}

class _PayNowDialog extends StatelessWidget {
  const _PayNowDialog({required this.total, required this.alreadyPaid, required this.maxPayable, required this.unlimitedWhenOpen, required this.onPay});
  final double total;
  final double alreadyPaid;
  final double maxPayable;
  final bool unlimitedWhenOpen;
  final Future<void> Function(double, String, String?) onPay;
  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('إضافة دفعة'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق'))],
      );
}
